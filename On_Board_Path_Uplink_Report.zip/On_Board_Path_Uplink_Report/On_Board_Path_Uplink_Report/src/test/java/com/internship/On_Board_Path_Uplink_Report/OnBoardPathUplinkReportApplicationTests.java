package com.internship.On_Board_Path_Uplink_Report;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnBoardPathUplinkReportApplicationTests {

	@Test
	void contextLoads() {
	}

}
