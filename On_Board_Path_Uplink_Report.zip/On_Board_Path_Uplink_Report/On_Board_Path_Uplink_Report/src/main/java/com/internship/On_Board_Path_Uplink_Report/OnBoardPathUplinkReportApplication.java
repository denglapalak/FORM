package com.internship.On_Board_Path_Uplink_Report;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnBoardPathUplinkReportApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnBoardPathUplinkReportApplication.class, args);
	}

}
